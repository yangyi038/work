package com.lagou.edu.factory;

import com.alibaba.druid.util.StringUtils;
import com.lagou.edu.annotation.Autowired;
import com.lagou.edu.annotation.Service;
import com.lagou.edu.annotation.Transactional;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.reflections.Reflections;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author 应癫
 *
 * 工厂类，生产对象（使用反射技术）
 */
public class BeanFactory {

    /**
     * 任务一：读取解析xml，通过反射技术实例化对象并且存储待用（map集合）
     * 任务二：对外提供获取实例对象的接口（根据id获取）
     */

    private static Map<String,Object> map = new HashMap<>();  // 存储对象


    static {
        // 任务一：读取解析xml，通过反射技术实例化对象并且存储待用（map集合）
        // 加载xml
        InputStream resourceAsStream = BeanFactory.class.getClassLoader().getResourceAsStream("beans.xml");
        // 解析xml
        SAXReader saxReader = new SAXReader();
        try {
            Document document = saxReader.read(resourceAsStream);
            Element rootElement = document.getRootElement();

            // 获取被扫描的包名
            List<Element> scanList = rootElement.selectNodes("//component-scan");

            // 解析包名
            for (int i = 0; i < scanList.size(); i++) {
                Element element = scanList.get(i);
                String s = element.attributeValue("base-package");

                // 循环扫描是否含有Service注解
                Set<Class<?>> serviceClass = getPackageClass(Service.class, s);
                for (Class<?> aClass : serviceClass) {
                    Service annotation = aClass.getAnnotation(Service.class);
                    String value = annotation.value();
                    if (StringUtils.isEmpty(value)){
                        Class<?> inter;
                        Class<?>[] interfaces = aClass.getInterfaces();
                        if (interfaces.length > 0){
                            inter = interfaces[0];
                        }else {
                            inter = aClass;
                        }
                        String object = inter.getName().substring(inter.getPackageName().length() + 1);
                        value = object.substring(0 ,1).toLowerCase() + object.substring(1);
                    }
                    Object o = aClass.newInstance();
                    map.put(value, o);
                }
            }

            // 循环查看类里面是否含有Autowired注解
            Set<String> stringSet = map.keySet();
            for (String string : stringSet) {
                Object o = map.get(string);
                Field[] fields = o.getClass().getDeclaredFields();
                for (Field field : fields) {
                    Autowired autowired = field.getAnnotation(Autowired.class);
                    if (autowired != null){
                        field.set(o, map.get(field.getName()));
                        map.put(string, o);
                    }
                }
            }

            // 循环查看类里面是否含有Transactional注解
            for (String s : stringSet) {
                Object o = map.get(s);
                ProxyFactory proxyFactory = (ProxyFactory) map.get("proxyFactory");
                if (o.getClass().getAnnotation(Transactional.class) != null){
                    map.put(s, proxyFactory.getCglibProxy(o));
                }
                Method[] methods = o.getClass().getMethods();
                for (Method method : methods) {
                    if (method.getAnnotation(Transactional.class) != null){
                        map.put(s, proxyFactory.getCglibProxy(o));
                    }
                }
            }
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }

    }


    // 任务二：对外提供获取实例对象的接口（根据id获取）
    public static  Object getBean(String id) {
        return map.get(id);
    }

    // 扫描报名，获取被注解类
    public static Set<Class<?>> getPackageClass(Class annotation, String packageName){
        Reflections f = new Reflections(packageName);
        return f.getTypesAnnotatedWith(annotation);
    }
}
