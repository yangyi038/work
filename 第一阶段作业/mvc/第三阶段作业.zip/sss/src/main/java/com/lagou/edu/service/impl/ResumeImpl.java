package com.lagou.edu.service.impl;

import com.lagou.edu.dao.ResumeDao;
import com.lagou.edu.pojo.Resume;
import com.lagou.edu.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ResumeImpl implements ResumeService {

    @Autowired
    private ResumeDao resumeDao;

    @Override
    public boolean add(Resume resume) {
        Resume save = resumeDao.save(resume);
        return true;
    }

    @Override
    public List<Resume> queryAll() {
        List<Resume> all = resumeDao.findAll();
        return all;
    }

    @Override
    public boolean edit(Resume resume) {
        resumeDao.save(resume);
        return true;
    }

    @Override
    public boolean delete(Long id) {
        resumeDao.deleteById(id);
        return true;
    }

    @Override
    public Resume queryOne(Long id) {
        Optional<Resume> byId = resumeDao.findById(id);
        return byId.get();
    }
}
