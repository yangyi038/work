package com.lagou.edu.service;

import com.lagou.edu.pojo.Resume;

import java.util.List;

public interface ResumeService {

    public boolean add(Resume resume);

    public List<Resume> queryAll();

    public boolean edit(Resume resume);

    public boolean delete(Long id);

    public Resume queryOne(Long id);
}
