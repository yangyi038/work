package com.lagou.edu.controller;

import com.lagou.edu.pojo.Resume;
import com.lagou.edu.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/resume")
public class ResumeController {

    @Autowired
    private ResumeService resumeService;

    @RequestMapping("/login")
    public ModelAndView login(){
        ModelAndView modelAndView = new ModelAndView();
        List<Resume> resumes = resumeService.queryAll();
        modelAndView.addObject("resumes", resumes);
        modelAndView.setViewName("list");
        return modelAndView;
    }

    @RequestMapping("/queryList")
    public ModelAndView queryList(){
        ModelAndView modelAndView = new ModelAndView();
        List<Resume> resumes = resumeService.queryAll();
        return modelAndView;
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ResponseBody
    public ModelAndView add(Resume resume, RedirectAttributes redirectAttributes){
        ModelAndView modelAndView = new ModelAndView();
        resumeService.add(resume);
        return modelAndView;
    }

    @RequestMapping("/edit")
    public ModelAndView edit(Resume resume){
        ModelAndView modelAndView = new ModelAndView();
        Resume resume1 = resumeService.queryOne(resume.getId());
        if (resume1 == null){
            modelAndView.setViewName("error");
            return null;
        }
        resumeService.edit(resume);
        return modelAndView;
    }

    @RequestMapping("/delete")
    public String delete(Long id){
        ModelAndView modelAndView = new ModelAndView();
        resumeService.delete(id);
        modelAndView.setViewName("list");
        return "redirect:login";
    }

    @RequestMapping("/skipAdd")
    public ModelAndView skipAdd(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("add");
        return modelAndView;
    }

    @RequestMapping("/skipEdit")
    public ModelAndView skipEdit(HttpServletRequest request){
        Resume resume = new Resume();
        ModelAndView modelAndView = new ModelAndView();
        resume.setId(Long.parseLong(request.getParameter("id")));
        resume.setName(request.getParameter("name"));
        resume.setAddress(request.getParameter("address"));
        resume.setPhone(request.getParameter("phone"));
        modelAndView.addObject("resume", resume);
        modelAndView.setViewName("edit");
        return modelAndView;
    }

    @RequestMapping("/error")
    public ModelAndView error(HttpServletRequest request){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        return modelAndView;
    }
}
