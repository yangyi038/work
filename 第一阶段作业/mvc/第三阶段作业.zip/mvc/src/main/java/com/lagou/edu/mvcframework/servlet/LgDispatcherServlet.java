package com.lagou.edu.mvcframework.servlet;

import com.lagou.edu.mvcframework.annotations.*;
import com.lagou.edu.mvcframework.pojo.Handler;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LgDispatcherServlet extends HttpServlet {

    private Properties properties = new Properties();

    // 缓存扫描到的类的全限定类名
    private List<String> classNames = new ArrayList<>();

    // ioc容器
    private Map<String, Object> ioc = new HashMap<>();

    // handlerMapping
    // 存储方法与URL的映射关系
    private List<Handler> handlers = new ArrayList<>();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 处理请求:根据URL找到对应的method，进行调用
        String requestURI = req.getRequestURI();

        // 获取到反射的方法
//        Method method = handlerMapping.get(requestURI);

        // 反射调用，需要传入对象，需要传入参数
        // 没有缓存对象，也没有参数，此处无法调用
        // 改造initHandlerMapping方法
//        method.invoke()

        try {
            // 根据URI获取当前处理的hanlder
            Handler handler = getHandle(req);
            if (handler == null){
                resp.getWriter().write("404 not found");
            }

            preMethod(req, resp, handler);

            // 参数绑定
            // 获取所有参数类型数组，数组的长度就是最后要传入的args数组的长度
            Class<?>[] parameterTypes = handler.getMethod().getParameterTypes();

            //根据上述数组长度，创建一个新的数组（参数数组，传入反射调用）
            Object[] paraValues = new Object[parameterTypes.length];

            // 以下就是为了向参数数组中塞值，而且还得保证参数的顺序和方法中的顺序一致
            Map<String, String[]> parameterMap = req.getParameterMap();

            // 遍历request中所有的参数，填充除了request和response之外的参数
            for (Map.Entry<String, String[]> param : parameterMap.entrySet()) {
                // name=1&name=2  name[1,2]
                    String join = StringUtils.join(param.getValue(), ","); // 如同1,2

                // 如果参数和方法中的参数匹配上了，填充数据
                if (!handler.getParamIndexMapping().containsKey(param.getKey())){
                    continue;
                }

                // 方法形参确实有该参数，找到它的索引位置，把对应的参数放入
                Integer index = handler.getParamIndexMapping().get(param.getKey());// name在第2个索引位置

                // 把前台传递过来的参数填充到对应的位置上吗
                paraValues[index] = join;
            }

            int requestIndex = handler.getParamIndexMapping().get(HttpServletRequest.class.getSimpleName());
            paraValues[requestIndex] = req;

            int responseIndex = handler.getParamIndexMapping().get(HttpServletResponse.class.getSimpleName());
            paraValues[responseIndex] = resp;

            // 最终调用handler的method属性

            handler.getMethod().invoke(handler.getController(), paraValues);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 调用方法之前执行
     * @param req
     */
    private void preMethod(HttpServletRequest req, HttpServletResponse resp,  Handler handler) throws Exception {
        String username = req.getParameter("username");
        Class<?> aClass = handler.getController().getClass();

        if (aClass.isAnnotationPresent(Security.class)){
            Security annotation = aClass.getAnnotation(Security.class);
            String[] value = annotation.value();
            if (!Arrays.asList(value).contains(username)){
                resp.getWriter().write("Permission verification failed");
            }
        }

        Method[] methods = aClass.getMethods();
        for (Method method : methods) {
            if (method.isAnnotationPresent(Security.class)){
                Security annotation = method.getAnnotation(Security.class);
                String[] value = annotation.value();
                if (!Arrays.asList(value).contains(username)){
                    if (!Arrays.asList(value).contains(username)){
                        resp.getWriter().write("Permission verification failed");
                    }
                }
            }
        }
    }

    /**
     * 通过URL获取handler
     * @param req
     * @return
     */
    private Handler getHandle(HttpServletRequest req) {
        if (handlers.isEmpty()) return null;

        String uri = req.getRequestURI();
        for (Handler handler : handlers) {
            Matcher matcher = handler.getPattern().matcher(uri);
            if (!matcher.matches()){
                continue;
            }
            return handler;
        }
        return null;
    }

    @Override
    public void init(ServletConfig config) throws ServletException {

        // 1.加载配置文件 springmvc.properties
        String contextConfigLocation = config.getInitParameter("contextConfigLocation");
        doLoadConfig(contextConfigLocation);

        // 2.扫描相关的类，扫描注解
        doScan(properties.getProperty("scanPackage"));

        // 3.初始化bean对象（实现IOC容器，基于注解）
        doInstance();

        // 4.实现依赖注入
        doAutoWired();

        // 5.构造一个handleMapping处理器映射器，将配置好的URL和method建立映射关系
        initHandlerMapping();

        System.out.println("lagou mvc 初始化完成。。。。");
        System.out.println("等待请求进入，处理请求");
    }

    /**
     * 构造映射器
     * 最关键环节
     * 目的：将URL和method建立关系
     */
    private void initHandlerMapping() {
        if (ioc.isEmpty()) return;

        for (Map.Entry<String, Object> stringObjectEntry : ioc.entrySet()) {
            // 获取当前IOC中当前遍历的对象的class类型
            Class<?> aClass = stringObjectEntry.getValue().getClass();

            if (!aClass.isAnnotationPresent(LaGouController.class)) {
                continue;
            }

            String baseUrl = "";
            if (aClass.isAnnotationPresent(LaGouRequestMapping.class)) {
                LaGouRequestMapping annotation = aClass.getAnnotation(LaGouRequestMapping.class);
                baseUrl = annotation.value();  // 等同于 /demo
            }

            // 获取方法
            Method[] methods = aClass.getMethods();
            for (Method method : methods) {
                // 方法没有标识LaGouRequestMapping  不处理
                if (!method.isAnnotationPresent(LaGouRequestMapping.class)) {
                    continue;
                }

                // 如果标识LaGouRequestMapping， 就处理
                LaGouRequestMapping annotation = method.getAnnotation(LaGouRequestMapping.class);
                String methodUrl = annotation.value(); // 等同于 /query
                String url = baseUrl + methodUrl;

                // 把method的所有信息及URL封装成一个Handle
                Handler handler = new Handler(stringObjectEntry.getValue(), method, Pattern.compile(url));

                // 处理计算方法参数位置信息
                // query(HttpServletRequest request, HttpServletResponse response, String name)
                Parameter[] parameters = method.getParameters();
                for (int i = 0; i < parameters.length; i++) {
                    Parameter parameter = parameters[i];
                    if (parameter.getType() == HttpServletRequest.class || parameter.getType() == HttpServletResponse.class) {
                        // 如果是request和response对象， 那么参数名称写HttpServletRequest和HttpServletResponse
                        handler.getParamIndexMapping().put(parameter.getType().getSimpleName(), i);
                    }else {
                        // <name, 2>
                        handler.getParamIndexMapping().put(parameter.getName(), i);
                    }
                }
                handlers.add(handler);
            }
        }
    }

    /**
     * 实现依赖注入
     */
    private void doAutoWired() {
        if (ioc.isEmpty()) {
            return;
        }

        // 有对象，再进行依赖注入处理
        // 遍历IOC中所有的对象，查看对象中是否含有@LagouAutowired注解，如果有就需要维护依赖注入关系
        for (Map.Entry<String, Object> stringObjectEntry : ioc.entrySet()) {

            // 对字段进行遍历
            Field[] declaredFields = stringObjectEntry.getValue().getClass().getDeclaredFields();
            for (Field declaredField : declaredFields) {
                if (!declaredField.isAnnotationPresent(LaGouAutoWired.class)) {
                    continue;
                }

                // 有该注解
                // 需要注入的bean的ID
                String value = declaredField.getAnnotation(LaGouAutoWired.class).value();
                if ("".equals(value.trim())) {
                    // 没有配置具体的beanID，就需要根据当前字段注入的类型注入（接口注入）
                    value = declaredField.getType().getName();
                }

                // 开启赋值
                declaredField.setAccessible(true);
                try {
                    declaredField.set(stringObjectEntry.getValue(), ioc.get(value));
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * IOC容器
     * 基于classNames缓存的类的全限定类名，以及反射技术，完成对象的创建和管理
     */
    private void doInstance() {
        if (classNames.size() == 0) return;

        try {
            // com.lagou.demo.controller.DemoController
            for (String className : classNames) {
                // 反射创建对象
                Class<?> aClass = Class.forName(className);

                // 区分controller，service
                if (aClass.isAnnotationPresent(LaGouController.class)) {
                    // controller的ID此处不做过多处理，不取value了，就拿类的首字母小写作为ID，保存到IOC容器中
                    String simpleName = aClass.getSimpleName();
                    String lowerFirstSimpleName = lowerFirst(simpleName); //demoController
                    Object o = aClass.newInstance();
                    ioc.put(lowerFirstSimpleName, o);
                } else if (aClass.isAnnotationPresent(LaGouService.class)) {
                    LaGouService annotation = aClass.getAnnotation(LaGouService.class);
                    // 获取注解value值
                    String beanName = annotation.value();
                    Object o = aClass.newInstance();
                    if (!"".equals(beanName)) {
                        ioc.put(beanName, o);
                    } else {
                        // 如果没有指定，就以类名首字母小写
                        beanName = lowerFirst(aClass.getSimpleName());
                        ioc.put(beanName, o);
                    }

                    // service层往往有接口的，面向接口开发，此时再以接口名为ID，放入一份到IOC容器中，便于后期根据接口类型注入
                    Class<?>[] interfaces = aClass.getInterfaces();
                    for (Class<?> anInterface : interfaces) {
                        // 以接口的类名为ID放入
                        ioc.put(anInterface.getName(), o);
                    }
                } else {
                    continue;
                }
            }
        } catch (Exception e) {
        }
    }

    /**
     * 扫描类
     * scanPackage:com.lagou.demo
     * package ---> 磁盘上的文件夹(File)
     */
    private void doScan(String scanPackage) {
        String scanPackagePath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + scanPackage.replaceAll("\\.", "/");
        File pack = new File(scanPackagePath);
        File[] files = pack.listFiles();
        for (File file : files) {
            if (file.isDirectory()) { // 子package
                doScan(scanPackage + "." + file.getName()); //com.lagou.demo.controller
            } else if (file.getName().endsWith(".class")) {
                String className = scanPackage + "." + file.getName().replaceAll(".class", "");
                classNames.add(className);
            }
        }
    }

    /**
     * 加载配置文件
     *
     * @param contextConfigLocation
     */
    private void doLoadConfig(String contextConfigLocation) {
        InputStream resourceAsStream = this.getClass().getClassLoader().getResourceAsStream(contextConfigLocation);
        try {
            properties.load(resourceAsStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 首字母小写
     *
     * @param str
     * @return
     */
    public String lowerFirst(String str) {
        char[] chars = str.toCharArray();
        if ('A' <= chars[0] && chars[0] <= 'Z') {
            chars[0] += 32;
        }
        return String.valueOf(chars);
    }
}
