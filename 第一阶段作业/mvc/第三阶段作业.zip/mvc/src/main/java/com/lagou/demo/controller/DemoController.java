package com.lagou.demo.controller;

import com.lagou.demo.service.DemoService;
import com.lagou.edu.mvcframework.annotations.LaGouAutoWired;
import com.lagou.edu.mvcframework.annotations.LaGouController;
import com.lagou.edu.mvcframework.annotations.LaGouRequestMapping;
import com.lagou.edu.mvcframework.annotations.Security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@LaGouController
@LaGouRequestMapping("/demo")
@Security({"zhangsan","lisi"})
public class DemoController {

    @LaGouAutoWired
    private DemoService demoService;

    /**
     * URL: /demo/query
     * @param request
     * @param response
     * @param name
     * @return
     */
    @LaGouRequestMapping("/query")
    public String query(HttpServletRequest request, HttpServletResponse response, String name){
        return demoService.get(name);
    }
}
