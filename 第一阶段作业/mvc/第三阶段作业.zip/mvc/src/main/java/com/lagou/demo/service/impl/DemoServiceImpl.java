package com.lagou.demo.service.impl;

import com.lagou.demo.service.DemoService;
import com.lagou.edu.mvcframework.annotations.LaGouService;

@LaGouService
public class DemoServiceImpl implements DemoService {

    @Override
    public String get(String name) {
        System.out.println("获取到名称：" + name);
        return name;
    }
}
