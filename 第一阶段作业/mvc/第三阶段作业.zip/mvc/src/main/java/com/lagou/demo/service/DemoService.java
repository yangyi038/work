package com.lagou.demo.service;

public interface DemoService {

    public String get(String name);
}
