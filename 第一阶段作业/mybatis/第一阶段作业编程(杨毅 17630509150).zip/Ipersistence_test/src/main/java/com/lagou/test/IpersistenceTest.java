package com.lagou.test;

import com.lagou.dao.IUserDao;
import com.lagou.io.Resources;
import com.lagou.pojo.User;
import com.lagou.sqlsession.SqlSession;
import com.lagou.sqlfactory.SqlSessionFactory;
import com.lagou.sqlfactory.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class IpersistenceTest {


    private IUserDao iUserDao;


    @Before
    public void before() throws Exception {
        InputStream resourceAsStream = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory build = new SqlSessionFactoryBuilder().build(resourceAsStream);
        SqlSession sqlSession = build.openSession();
        iUserDao = sqlSession.getMapper(IUserDao.class);
    }


    @Test
    public void testQuery() throws Exception {
        List<User> users = iUserDao.findAll();
        for (User user2 : users) {
            System.out.println(user2);
        }
    }

    @Test
    public void testUpdate() {
        User user = new User();
        user.setUsername("222222");
        user.setId(2);
        iUserDao.updateUser(user);
    }

    @Test
    public void testDelete() {
        iUserDao.deleteUser(6);
    }
}
