package com.lagou.sqlfactory;

import com.lagou.sqlsession.SqlSession;

public interface SqlSessionFactory {

    public SqlSession openSession();
}
