package com.lagou.sqlsession;

import com.lagou.executor.SimpleExecutor;
import com.lagou.pojo.Configuration;
import com.lagou.pojo.MappedStatement;

import java.lang.reflect.*;
import java.util.List;

public class DefaultSqlSession implements SqlSession {

    private Configuration configuration;

    public DefaultSqlSession(Configuration configuration) {
        this.configuration = configuration;
    }

    @Override
    public <E> List<E> selectList(String statementid, Object... params) throws Exception {

        // 将要完成对SimpleExecutor里的query方法的调用
        SimpleExecutor simpleExecutor = new SimpleExecutor();
        MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statementid);
        List<Object> query = simpleExecutor.query(configuration, mappedStatement, params);

        return (List<E>) query;
    }

    @Override
    public <T> T selectOne(String statementid, Object... params) throws Exception {
        List<Object> objects = selectList(statementid, params);
        if (objects.size() == 1) {
            return (T) objects.get(0);
        } else {
            throw new RuntimeException("查询结果为空，或者返回结果过多");
        }
    }

    @Override
    public Integer insert(String statementid, Object... params) throws Exception {
        return update(statementid, params);
    }

    @Override
    public Integer update(String statementid, Object... params) throws Exception {
        SimpleExecutor simpleExecutor = new SimpleExecutor();
        MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statementid);
        Integer result = simpleExecutor.doUpdate(configuration, mappedStatement, params);
        return result;
    }

    @Override
    public Integer delete(String statementid, Object... params) throws Exception {
        SimpleExecutor simpleExecutor = new SimpleExecutor();
        MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statementid);
        Integer result = simpleExecutor.doDelete(configuration, mappedStatement, params);
        return result;
    }

    @Override
    public <T> T getMapper(Class<?> mapperClass) {
        // 使用JDK动态代理来为Dao接口生成代理对象，并返回
        Object proxyInstance = Proxy.newProxyInstance(DefaultSqlSession.class.getClassLoader(), new Class[]{mapperClass}, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                // 底层执行JDBC代码  //根据不同情况来调用selectList和selectOne
                // 准备参数 1.statmentId : sql语句的唯一标志
                String methodName = method.getName();
                String className = method.getDeclaringClass().getName();
                String statementId = className + "." + methodName;
                MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statementId);
                String sql = mappedStatement.getSql();
                String substring = sql.substring(0, 6);
                if (substring.toLowerCase().equals("select")){
                    // 准备参数 2.params args
                    // 获取被调用方法的返回值类型
                    Type genericReturnType = method.getGenericReturnType();
                    if (genericReturnType instanceof ParameterizedType) {
                        List<Object> list = selectList(statementId, args);
                        return list;
                    }
                    return selectOne(statementId, args);
                }
                if (substring.toLowerCase().equals("update")){
                    return update(statementId, args);
                }
                if (substring.toLowerCase().equals("delete")){
                    return delete(statementId, args);
                }
                throw new Exception("Unknown execution method for: " + method.getName());
            }
        });

        return (T) proxyInstance;
    }
}
